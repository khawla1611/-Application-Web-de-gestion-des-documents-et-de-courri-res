
-- --------------------------------------------------------

--
-- Structure de la table `documentssub`
--

DROP TABLE IF EXISTS `documentssub`;
CREATE TABLE IF NOT EXISTS `documentssub` (
  `id` int NOT NULL AUTO_INCREMENT,
  `subject_id` int NOT NULL,
  `document_path` varchar(255) NOT NULL,
  `document_type` enum('pdf','image','video') NOT NULL,
  `uploaded_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `subject_id` (`subject_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
