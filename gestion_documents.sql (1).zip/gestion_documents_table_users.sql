
-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` enum('admin','superadmin') NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `reset_token_hash` varchar(64) DEFAULT NULL,
  `reset_token_expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `role`, `created_at`, `updated_at`, `reset_token_hash`, `reset_token_expires_at`) VALUES
(16, 'ilyass', '$2y$10$UzIbafIVQB3oFQhXNnnPiuGMEuwXxShN3oA.UpOIL.m8I35DyZzxi', 'qf17012003@gmail.com', 'admin', '2024-09-05 10:50:30', '2024-09-09 10:03:25', NULL, NULL),
(1, 'superadmin', '$2y$10$fvvLxEMmpt/s9vXGaMYNm.Lx76ob5br/pAYT3CpPJghV8KnSMYjyG', 'superadmin@gmail.com', 'superadmin', '2024-07-25 09:46:34', '2024-09-11 13:30:57', NULL, NULL);
